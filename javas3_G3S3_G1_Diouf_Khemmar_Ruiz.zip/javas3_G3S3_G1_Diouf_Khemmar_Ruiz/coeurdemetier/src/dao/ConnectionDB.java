/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.beans.Statement;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

/**
 *
 * @author julia
 */
public class ConnectionDB {

    private static ConnectionDB instance = null;
    
    public static Connection getInstance() {
        if(instance == null)
            instance = new ConnectionDB();
        
        return instance.con;
    }
    
    private String userName,password,url,driver;
    Connection con;
    //Statement st;

    private ConnectionDB() {
        FileInputStream file = null;
        
        Properties props = new Properties();
           try {
             
               
              
                userName="p1812347";
                password="375305";
                String database="p1812347";
                int port = 3306;
                String server = "iutdoua-web.univ-lyon1.fr";
                url="jdbc:mysql://"+server+":"+port+"/" +database;
                driver="org.mariadb.jdbc.Driver";

               
                Class.forName(driver);
                con=DriverManager.getConnection(url, userName, password);
                
                //st = (Statement) con.createStatement();
                
                System.out.println("Connection to database is successful");
            } catch (Exception e) {
                e.printStackTrace();
            }
    }
    
}
